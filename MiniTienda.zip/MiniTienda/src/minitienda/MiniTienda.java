package minitienda;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MiniTienda {
    static final String ARCHIVO = "ventas.txt";

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\n=== SISTEMA DE VENTAS ===");
            System.out.println("1. Registrar venta");
            System.out.println("2. Consultar ventas");
            System.out.println("3. Actualizar venta");
            System.out.println("4. Eliminar venta");
            System.out.println("5. Salir");
            System.out.print("Opcion: ");
            opcion = sc.nextInt();
            sc.nextLine(); 

            switch (opcion) {
                case 1:
                    registrarVenta(sc);
                    break;
                case 2:
                    consultarVentas();
                    break;
                case 3:
                    actualizarVenta(sc);
                    break;
                case 4:
                    eliminarVenta(sc);
                    break;
                case 5:
                    System.out.println("Saliendo");
                    break;
                default:
                    System.out.println("Opcion no válida.");
            }
        } while (opcion != 5);

        sc.close();
    }

   
    public static void registrarVenta(Scanner sc) {
        try (FileWriter fw = new FileWriter(ARCHIVO, true);
             BufferedWriter bw = new BufferedWriter(fw)) {

            System.out.print("Codigo del producto: ");
            String codigo = sc.nextLine();
            System.out.print("Nombre del producto: ");
            String nombre = sc.nextLine();
            System.out.print("Cantidad vendida: ");
            int cantidad = sc.nextInt();
            System.out.print("Precio unitario: ");
            double precio = sc.nextDouble();
            sc.nextLine(); 
            System.out.print("Fecha (YYYY-MM-DD): ");
            String fecha = sc.nextLine();

            String registro = codigo + "," + nombre + "," + cantidad + "," + precio + "," + fecha;
            bw.write(registro);
            bw.newLine();

            System.out.println(" Venta registrada correctamente.");

        } catch (IOException e) {
            System.out.println("Error al registrar venta.");
        }
    }

    
    public static void consultarVentas() {
        try (BufferedReader br = new BufferedReader(new FileReader(ARCHIVO))) {
            String linea;
            System.out.println("\n LISTA DE VENTAS:");
            while ((linea = br.readLine()) != null) {
                System.out.println(linea);
            }
        } catch (IOException e) {
            System.out.println("No se pudo leer el archivo.");
        }
    }

  
    public static void actualizarVenta(Scanner sc) {
        try {
            List<String> lineas = new ArrayList<>();
            BufferedReader br = new BufferedReader(new FileReader(ARCHIVO));
            String linea;
            System.out.print("Codigo del producto a actualizar: ");
            String codigo = sc.nextLine();
            boolean encontrado = false;

            while ((linea = br.readLine()) != null) {
                if (linea.startsWith(codigo + ",")) {
                    System.out.println("Venta encontrada: " + linea);
                    System.out.print("Nuevo nombre del producto: ");
                    String nombre = sc.nextLine();
                    System.out.print("Nueva cantidad vendida: ");
                    int cantidad = sc.nextInt();
                    System.out.print("Nuevo precio unitario: ");
                    double precio = sc.nextDouble();
                    sc.nextLine();
                    System.out.print("Nueva fecha (YYYY-MM-DD): ");
                    String fecha = sc.nextLine();

                    linea = codigo + "," + nombre + "," + cantidad + "," + precio + "," + fecha;
                    encontrado = true;
                }
                lineas.add(linea);
            }
            br.close();

            BufferedWriter bw = new BufferedWriter(new FileWriter(ARCHIVO));
            for (String l : lineas) {
                bw.write(l);
                bw.newLine();
            }
            bw.close();

            if (encontrado) {
                System.out.println(" Venta actualizada correctamente.");
            } else {
                System.out.println(" Venta no encontrada.");
            }
        } catch (IOException e) {
            System.out.println("Error al actualizar venta.");
        }
    }

    
    public static void eliminarVenta(Scanner sc) {
    try {
        List<String> lineas = new ArrayList<>();
        BufferedReader br = new BufferedReader(new FileReader(ARCHIVO));
        String linea;
        System.out.print("Código del producto a eliminar: ");
        String codigo = sc.nextLine();
        boolean eliminado = false;

        while ((linea = br.readLine()) != null) {
            if (!linea.startsWith(codigo + ",")) {
                // Si NO coincide, lo guardamos
                lineas.add(linea);
            } else {
                // Si coincide, no lo agregamos (lo eliminamos)
                eliminado = true;
            }
        }
        br.close();

        BufferedWriter bw = new BufferedWriter(new FileWriter(ARCHIVO));
        for (String l : lineas) {
            bw.write(l);
            bw.newLine();
        }
        bw.close();

        if (eliminado) {
            System.out.println(" Venta eliminada correctamente.");
        } else {
            System.out.println(" Venta no encontrada.");
        }

    } catch (IOException e) {
        System.out.println("Error al eliminar venta.");
    }
}

    
   }
